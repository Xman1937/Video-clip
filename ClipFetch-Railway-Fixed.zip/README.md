# ClipFetch

Mobile-friendly React + Express + PostgreSQL application for downloading direct video-file URLs that you own or are authorized to download.

## Railway deployment

1. Push this folder's contents to the root of your GitHub repository.
2. In Railway, create a project from that GitHub repository.
3. Add a PostgreSQL database to the Railway project.
4. In the app service Variables, set `DATABASE_URL` to the PostgreSQL service's `DATABASE_URL` reference. Set `SERVE_FRONTEND=true`, `DATABASE_SSL=true`, and `MAX_DOWNLOAD_MB=500`.
5. Deploy. Railway reads `railway.json`, builds the React client, starts Express, and checks `/api/health`.
6. Generate a public domain in Railway's Networking settings.

The app serves the frontend and API from one service/domain. `CLIENT_ORIGIN` is only needed if you later host the client on a separate domain; set it to that exact origin.

## Local development

Requirements: Node.js 20+ and Docker.

1. Copy `.env.example` to `server/.env` and set `DATABASE_URL` to your local PostgreSQL connection string. For local PostgreSQL, set `DATABASE_SSL=false` and `SERVE_FRONTEND=false`.
2. Start the database: `docker compose up -d db` (change the sample password before use and use the same password in `DATABASE_URL`).
3. Install dependencies: `npm install`
4. Run both apps: `npm run dev`
5. Open `http://localhost:5173`.

## Limitations and safety

- This starter downloads direct public video-file URLs only. It does not extract videos from YouTube, Instagram, Facebook, TikTok, private accounts, DRM, or paywalled pages.
- Only download videos you own or have permission to download.
- Files are streamed through the server and are not stored permanently. Only basic recent activity metadata is stored in PostgreSQL.
- Before opening to significant public traffic, add rate limiting, request quotas, abuse monitoring, and network-level outbound restrictions. Downloads consume your server's bandwidth and can create hosting costs.
