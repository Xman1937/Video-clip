# Railway-first deployment and Hostinger migration

## Recommended Railway layout
Use one Railway project with:
1. `web` service from this repository, running the Node/Express server and built React frontend.
2. Railway PostgreSQL service.

For a single-service frontend + backend, set these variables on the `web` service:
- `PORT` is supplied by Railway automatically; do not hard-code it.
- `DATABASE_URL` reference the Railway PostgreSQL service's `DATABASE_URL`.
- `CLIENT_ORIGIN` set to the public Railway app URL (or your custom domain).
- `SESSION_SECRET` set to a long random secret.
- `SERVE_FRONTEND=true`

Set the build command to:
`npm install && npm run build`
Set the start command to:
`npm run start -w server`
Set healthcheck path to:
`/api/health`

Note: This repository's frontend uses `/api` paths, so serving frontend and API from the same domain avoids CORS and cross-origin setup.

## Database migration to Hostinger
Before moving:
1. Create a PostgreSQL database on the destination Hostinger VPS (PostgreSQL generally requires VPS on Hostinger; standard web/cloud plans may not include it).
2. Put the destination `DATABASE_URL` into the Hostinger environment.
3. Export Railway PostgreSQL using `pg_dump` from a trusted machine:
   `pg_dump "$SOURCE_DATABASE_URL" --no-owner --no-acl -Fc -f clipfetch.dump`
4. Restore into destination:
   `pg_restore --clean --if-exists --no-owner --no-acl --dbname="$DEST_DATABASE_URL" clipfetch.dump`
5. Deploy the same repository to Hostinger, set `SERVE_FRONTEND=true`, `DATABASE_URL`, `SESSION_SECRET`, and the production `CLIENT_ORIGIN`.
6. Test `/api/health`, a direct video link you are authorized to download, history, HTTPS, and domain routing.
7. Only then switch the domain's DNS to Hostinger.

Keep a backup and do not delete Railway until the new site and database are confirmed working. Avoid simultaneous writes during final database migration or schedule a short maintenance window.

## Important limits
This starter supports public direct video-file links only. Platform page URLs are deliberately rejected; add official/authorized integrations for any platforms you are permitted to support. Use only videos you own or have permission to download.
