# Video Downloader (working starter)

A mobile-friendly React + Express + PostgreSQL starter for downloading **direct video-file URLs that you own or are authorized to download**.

## Important platform limitations
This project intentionally does not bypass DRM, logins, paywalls, or platform download restrictions. A YouTube, Instagram, Facebook, or TikTok page URL is not the same as a direct video-file URL, and this starter will reject those page URLs rather than pretending to download them. To support a platform, integrate its official API or an authorized provider and follow its terms and copyright rules.

## Requirements
- Node.js 20+
- Docker Desktop (recommended) or PostgreSQL 14+

## Run locally
1. Install Node.js 20+ and Docker.
2. Copy `.env.example` to `server/.env`.
3. In `docker-compose.yml`, change `POSTGRES_PASSWORD` and update `DATABASE_URL` in `server/.env` to match.
4. Run the database: `docker compose up -d db`
5. Install dependencies: `npm install`
6. Start app: `npm run dev`
7. Open `http://localhost:5173`

The API starts at `http://localhost:4000`. It creates its database table automatically at startup.

## Production notes
- Deploy the frontend and backend behind HTTPS.
- Use a managed PostgreSQL database and set `DATABASE_URL`, `CLIENT_ORIGIN`, and a long random `SESSION_SECRET`.
- Configure a reverse proxy / hosting provider to allow long-lived streaming responses.
- Do not expose the database publicly. Add rate limiting and authentication before opening it to the public.
- Download history is intentionally minimal and does not store video content. Downloads are streamed through the server and are not saved permanently.
- SSRF safeguards block localhost/private IPs and non-HTTP(S) protocols. Network-level egress restrictions are still recommended.

## Railway-first deploy
See `RAILWAY-HOSTINGER-DEPLOY.md` for environment variables, build/start commands, and the database migration checklist. For a single-domain deployment, set `SERVE_FRONTEND=true` and build the React app; the Express service will serve both the frontend and `/api` routes.
