import React, { useEffect, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { Link2, Download, ShieldCheck, Zap, History, CircleHelp, Video, CheckCircle2, AlertCircle, LoaderCircle, ExternalLink } from 'lucide-react';
import './styles.css';

function App() {
  const [url, setUrl] = useState('');
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState(null);
  const [history, setHistory] = useState([]);
  const [health, setHealth] = useState('checking');

  async function loadHistory() {
    try { const r = await fetch('/api/history'); const d = await r.json(); if (r.ok) setHistory(d.items || []); } catch {}
  }
  useEffect(() => {
    fetch('/api/health').then(r => r.json()).then(d => setHealth(d.ok ? 'online' : 'offline')).catch(() => setHealth('offline'));
    loadHistory();
  }, []);

  async function downloadVideo(e) {
    e.preventDefault();
    setMessage(null);
    if (!url.trim()) { setMessage({ type: 'error', text: 'Pehle video URL paste karein.' }); return; }
    setBusy(true);
    try {
      const response = await fetch('/api/download', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: url.trim() })
      });
      const contentType = response.headers.get('content-type') || '';
      if (!response.ok || contentType.includes('application/json')) {
        const data = await response.json().catch(() => ({}));
        throw new Error(data.error || 'Download nahi ho saka. URL check karein.');
      }
      const blob = await response.blob();
      const disposition = response.headers.get('content-disposition') || '';
      const match = disposition.match(/filename="([^"]+)"/);
      const filename = match?.[1] || 'video.mp4';
      const objectUrl = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = objectUrl; a.download = filename; document.body.appendChild(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(objectUrl), 30000);
      setMessage({ type: 'success', text: 'Download shuru ho gaya. Apne browser ke Downloads folder mein check karein.' });
      setUrl('');
      loadHistory();
    } catch (err) { setMessage({ type: 'error', text: err.message || 'Network error. Server check karein.' }); }
    finally { setBusy(false); }
  }

  const fmt = (bytes) => {
    const n = Number(bytes || 0);
    if (!n) return '0 B';
    const units = ['B','KB','MB','GB']; const i = Math.min(Math.floor(Math.log(n)/Math.log(1024)), 3);
    return `${(n / (1024 ** i)).toFixed(i ? 1 : 0)} ${units[i]}`;
  };

  return <div className="app-shell">
    <header className="topbar">
      <a className="brand" href="#"><span className="brand-mark"><Video size={22}/></span><span>Clip<span className="brand-accent">Fetch</span></span></a>
      <div className={`status ${health}`}><span className="status-dot"></span>{health === 'checking' ? 'Checking server' : health === 'online' ? 'Service online' : 'Service offline'}</div>
    </header>
    <main>
      <section className="hero">
        <div className="eyebrow"><span className="eyebrow-icon"><Zap size={14}/></span> SIMPLE. FAST. RESPONSIBLE.</div>
        <h1>Video downloads,<br/><span>made simple.</span></h1>
        <p className="hero-copy">Paste a direct video-file link and save it to your device. Free to use for videos you own or have permission to download.</p>
        <div className="download-card">
          <form onSubmit={downloadVideo}>
            <label htmlFor="video-url">Video URL</label>
            <div className="url-input-wrap"><Link2 size={20}/><input id="video-url" type="url" placeholder="https://example.com/my-video.mp4" value={url} onChange={e => setUrl(e.target.value)} disabled={busy}/>{url && <button type="button" className="clear-btn" onClick={() => setUrl('')} aria-label="Clear URL">×</button>}</div>
            <button className="download-btn" type="submit" disabled={busy || health !== 'online'}>{busy ? <><LoaderCircle className="spin" size={19}/> Processing video...</> : <><Download size={19}/> Download Video</>}</button>
          </form>
          {message && <div className={`notice ${message.type}`} role="status">{message.type === 'success' ? <CheckCircle2 size={18}/> : <AlertCircle size={18}/>}<span>{message.text}</span></div>}
          <div className="card-foot"><ShieldCheck size={16}/><span>Use only links you own or are authorized to download.</span></div>
        </div>
        <div className="platform-note"><strong>Supported:</strong> direct MP4, WebM and other public video-file links. <strong>Platform pages:</strong> YouTube, Instagram, Facebook and TikTok pages require official or authorized integrations.</div>
      </section>
      <section className="features">
        <div className="section-heading"><span>BUILT FOR EVERYDAY USE</span><h2>Easy from link to file</h2></div>
        <div className="feature-grid">
          <article className="feature"><div className="feature-icon blue"><Link2/></div><h3>Paste a link</h3><p>Use a direct link to a public video file. No account is needed for this starter.</p></article>
          <article className="feature"><div className="feature-icon violet"><Zap/></div><h3>Stream to device</h3><p>The server streams the file instead of keeping a permanent copy on the server.</p></article>
          <article className="feature"><div className="feature-icon green"><ShieldCheck/></div><h3>Safer by design</h3><p>Validates URLs, blocks private network hosts and limits file size.</p></article>
        </div>
      </section>
      <section className="history-section">
        <div className="history-title"><div><div className="section-kicker"><History size={16}/> RECENT ACTIVITY</div><h2>Download history</h2></div><button className="refresh-btn" onClick={loadHistory}>Refresh</button></div>
        {history.length ? <div className="history-list">{history.map(item => <div className="history-row" key={item.id}><div className="file-icon"><Video size={18}/></div><div className="history-info"><strong>{item.filename}</strong><span>{item.source_host} · {fmt(item.bytes)}</span></div><span className={`job-status ${item.status}`}>{item.status}</span></div>)}</div> : <div className="empty-state"><div className="empty-icon"><History size={24}/></div><strong>No downloads yet</strong><span>Your recent download activity will appear here.</span></div>}
      </section>
      <section className="faq">
        <div className="section-kicker"><CircleHelp size={16}/> GOOD TO KNOW</div><h2>Before you download</h2>
        <p>Paste a direct file URL, not a page where a video is embedded. This website does not bypass DRM, private accounts, or platform restrictions. Respect copyright and the source website's terms.</p>
      </section>
    </main>
    <footer><a className="brand footer-brand" href="#"><span className="brand-mark"><Video size={18}/></span><span>Clip<span className="brand-accent">Fetch</span></span></a><span>Download responsibly. © {new Date().getFullYear()} ClipFetch</span><a href="mailto:support@example.com" className="footer-link">Contact <ExternalLink size={13}/></a></footer>
  </div>;
}
createRoot(document.getElementById('root')).render(<App />);
