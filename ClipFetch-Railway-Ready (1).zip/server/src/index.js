import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import pg from 'pg';
import dns from 'node:dns/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import net from 'node:net';
import { pipeline } from 'node:stream/promises';

const { Pool } = pg;
const app = express();
const port = Number(process.env.PORT || 4000);
const pool = new Pool({ connectionString: process.env.DATABASE_URL, ssl: process.env.DATABASE_SSL === 'true' ? { rejectUnauthorized: true } : undefined });
const maxBytes = Math.max(1, Number(process.env.MAX_DOWNLOAD_MB || 500)) * 1024 * 1024;

app.use(helmet());
app.use(cors({ origin: process.env.CLIENT_ORIGIN || 'http://localhost:5173' }));
app.use(express.json({ limit: '20kb' }));

// Optional single-service deployment: set SERVE_FRONTEND=true and build client/dist.
const __dirname = path.dirname(fileURLToPath(import.meta.url));
if (process.env.SERVE_FRONTEND === 'true') {
  const distDir = path.resolve(__dirname, '../../client/dist');
  app.use(express.static(distDir));
}

await pool.query(`
  CREATE TABLE IF NOT EXISTS download_jobs (
    id BIGSERIAL PRIMARY KEY,
    source_host TEXT NOT NULL,
    filename TEXT NOT NULL,
    bytes BIGINT NOT NULL DEFAULT 0,
    status TEXT NOT NULL CHECK (status IN ('completed','failed')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
  )
`);

function isPrivateIPv4(ip) {
  const p = ip.split('.').map(Number);
  if (p.length !== 4 || p.some(n => !Number.isInteger(n) || n < 0 || n > 255)) return true;
  return p[0] === 10 || p[0] === 127 || p[0] === 0 ||
    (p[0] === 169 && p[1] === 254) || (p[0] === 172 && p[1] >= 16 && p[1] <= 31) ||
    (p[0] === 192 && p[1] === 168) || p[0] >= 224;
}
function isPrivateIPv6(ip) {
  const x = ip.toLowerCase();
  return x === '::1' || x === '::' || x.startsWith('fe80:') || x.startsWith('fc') || x.startsWith('fd') || x.startsWith('ff');
}
async function validatePublicUrl(raw) {
  let u;
  try { u = new URL(raw); } catch { throw new Error('Please enter a valid URL.'); }
  if (!['http:', 'https:'].includes(u.protocol)) throw new Error('Only HTTP and HTTPS links are supported.');
  if (u.username || u.password) throw new Error('URLs containing usernames or passwords are not supported.');
  const host = u.hostname.toLowerCase().replace(/^\[|\]$/g, '');
  if (host === 'localhost' || host.endsWith('.localhost') || host.endsWith('.local')) throw new Error('This host is not allowed.');
  if (net.isIP(host)) {
    if ((net.isIPv4(host) && isPrivateIPv4(host)) || (net.isIPv6(host) && isPrivateIPv6(host))) throw new Error('Private network addresses are not allowed.');
  } else {
    let records;
    try { records = await dns.lookup(host, { all: true }); } catch { throw new Error('Could not resolve that host.'); }
    if (!records.length || records.some(r => (net.isIPv4(r.address) && isPrivateIPv4(r.address)) || (net.isIPv6(r.address) && isPrivateIPv6(r.address)))) {
      throw new Error('This host resolves to a private or blocked address.');
    }
  }
  return u;
}
const blockedPageHosts = [
  'youtube.com','www.youtube.com','m.youtube.com','youtu.be',
  'instagram.com','www.instagram.com',
  'facebook.com','www.facebook.com','m.facebook.com','fb.watch',
  'tiktok.com','www.tiktok.com','vm.tiktok.com'
];
function safeFilename(value, fallback = 'video') {
  const cleaned = String(value || fallback).normalize('NFKD').replace(/[^\w.\- ]/g, '').trim().replace(/\s+/g, '_').slice(0, 120);
  return cleaned || fallback;
}
function filenameFromUrl(url) {
  const raw = decodeURIComponent(url.pathname.split('/').pop() || 'video');
  return safeFilename(raw.includes('.') ? raw : `${raw}.mp4`);
}

app.get('/api/health', async (_req, res) => {
  try { await pool.query('SELECT 1'); res.json({ ok: true, database: 'connected' }); }
  catch { res.status(503).json({ ok: false, database: 'unavailable' }); }
});

app.post('/api/download', async (req, res) => {
  let source;
  try {
    const input = String(req.body?.url || '').trim();
    if (!input || input.length > 2048) return res.status(400).json({ error: 'Paste a video URL (up to 2048 characters).' });
    source = await validatePublicUrl(input);
    if (blockedPageHosts.includes(source.hostname.toLowerCase())) {
      return res.status(400).json({ error: 'This is a platform page URL, not a direct video file. Use an official download option or an authorized platform API integration.' });
    }

    // Fetch only public direct-file links. Redirects are followed manually and revalidated to reduce SSRF risk.
    let current = source;
    let upstream;
    for (let i = 0; i < 4; i++) {
      upstream = await fetch(current, { redirect: 'manual', signal: AbortSignal.timeout(30000), headers: { 'User-Agent': 'VideoDownloader/1.0' } });
      if ([301,302,303,307,308].includes(upstream.status)) {
        const location = upstream.headers.get('location');
        if (!location) throw new Error('The source returned an invalid redirect.');
        current = await validatePublicUrl(new URL(location, current).toString());
        continue;
      }
      break;
    }
    if (!upstream || !upstream.ok) throw new Error(`The source could not be downloaded (HTTP ${upstream?.status || 'unknown'}).`);
    const type = (upstream.headers.get('content-type') || '').toLowerCase();
    if (!(type.startsWith('video/') || type === 'application/octet-stream' || type === 'binary/octet-stream')) {
      await upstream.body?.cancel();
      throw new Error('That link does not appear to be a direct video file. Paste a direct .mp4, .webm, or other video-file URL.');
    }
    const declaredLength = Number(upstream.headers.get('content-length') || 0);
    if (declaredLength > maxBytes) {
      await upstream.body?.cancel();
      throw new Error(`Video exceeds the configured ${Math.round(maxBytes / 1024 / 1024)} MB limit.`);
    }
    const filename = filenameFromUrl(current);
    res.setHeader('Content-Type', type || 'application/octet-stream');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.setHeader('Cache-Control', 'no-store');
    let bytes = 0;
    const reader = upstream.body.getReader();
    const { Readable } = await import('node:stream');
    const stream = new Readable({
      async read() {
        try {
          const { done, value } = await reader.read();
          if (done) return this.push(null);
          bytes += value.byteLength;
          if (bytes > maxBytes) {
            reader.cancel().catch(() => {});
            this.destroy(new Error('Download size limit exceeded.'));
          } else this.push(Buffer.from(value));
        } catch (e) { this.destroy(e); }
      },
      destroy(err, cb) { reader.cancel().catch(() => {}); cb(err); }
    });
    res.on('finish', async () => {
      try { await pool.query('INSERT INTO download_jobs(source_host, filename, bytes, status) VALUES ($1,$2,$3,$4)', [source.hostname, filename, bytes, 'completed']); } catch {}
    });
    res.on('close', async () => {
      if (!res.writableFinished) {
        try { await pool.query('INSERT INTO download_jobs(source_host, filename, bytes, status) VALUES ($1,$2,$3,$4)', [source.hostname, filename, bytes, 'failed']); } catch {}
      }
    });
    await pipeline(stream, res);
  } catch (e) {
    if (!res.headersSent) res.status(400).json({ error: e.message || 'Download failed. Check the URL and try again.' });
    else res.destroy();
  }
});

app.get('/api/history', async (_req, res) => {
  try {
    const { rows } = await pool.query('SELECT id, source_host, filename, bytes, status, created_at FROM download_jobs ORDER BY created_at DESC LIMIT 20');
    res.json({ items: rows });
  } catch { res.status(500).json({ error: 'Could not load download history.' }); }
});

if (process.env.SERVE_FRONTEND === 'true') {
  app.get('*', (req, res, next) => {
    if (req.path.startsWith('/api/')) return next();
    res.sendFile(path.resolve(__dirname, '../../client/dist/index.html'));
  });
}

app.listen(port, '0.0.0.0', () => console.log(`Video Downloader API listening on port ${port}`));
